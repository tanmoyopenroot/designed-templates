document.addEventListener('DOMContentLoaded', function () {
  particleground(document.getElementById('introParticleGround'), {
    dotColor: '#cccccc',
    lineColor: '#cccccc'
  });
}, false);


document.addEventListener('DOMContentLoaded', function () {
  particleground(document.getElementById('sponsorParticleGround'), {
    dotColor: '#cccccc',
    lineColor: '#cccccc'
  });
}, false);

document.addEventListener('DOMContentLoaded', function () {
  particleground(document.getElementById('teamParticleGround'), {
    dotColor: '#cccccc',
    lineColor: '#cccccc'
  });
}, false);

document.addEventListener('DOMContentLoaded', function () {
  particleground(document.getElementById('infoParticleGround'), {
    dotColor: '#cccccc',
    lineColor: '#cccccc'
  });
}, false);
