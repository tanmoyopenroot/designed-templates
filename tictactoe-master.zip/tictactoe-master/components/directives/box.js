var gameApp=angular.module("gameApp",[]);

gameApp.directive("tttBoard",function(){
    return {
        restrict: 'C',
        templateUrl: 'components/directives/board.html',
        link: function($scope, element, attrs){}
    }
});