angular.module("gameApp",['ngRoute'])

//Runs When The App Gets Kicked Off
.run([function(){
    console.log("Run Hook");
}])

//Route Config    
.config(['$routeProvider',
    function($routeProvider){
        console.log($routeProvider);
        $routeProvider
        .when('/',{
            controller:'singleController',
            templateUrl:'components/route/single.html'
        })
        .when('/multi',{
            controller:'multiController',
            templateUrl:'components/route/multi.html'
        })
        .when('/about',{
            templateUrl:'components/route/about.html'
        })
        .otherwise({
            redirectTo: '/'
        });
    }
])

//Game Board Directive
.directive('gameBoard',function(){
    return {
        restrict: 'C',
        templateUrl: 'components/directives/board.html',
        controller: function($scope){
            console.log("Board Directive Woring");
        },
        link: function($scope, element, attrs){}
    }
})

//Game Board Directive
.directive('gameScore',function(){
    return {
        restrict: 'C',
        templateUrl: 'components/directives/score.html',
        controller: function($scope){
            console.log("Game Directive Woring");
        },
        link: function($scope, element, attrs){}
    }
})


.directive('myDirective', function(){ 
    return { 
        restrict: 'A', 
        replace: true, 
        scope: { 
            myUrl: '@', // binding strategy 
            myLinkText: '@' // binding strategy 
        }, 
        template: '<a href="{{myUrl}}">' + '{{myLinkText}}</a>' 
    }
})

//Game factory
//.factory('game', function() { 
//    return { 
//        allPossMove: function() { 
//        } 
//    } 
//}) 

//Game Controller
.controller("singleController",function($scope,game)
{  
    $scope.spWin=0;
    $scope.cpuWin=0;
    
    var tArray=[
        ["","",""],
        ["","",""],
        ["","",""]
    ];
    var allPossMoves=[];
    
    var gameState={
        OrgPlayer:"",
        OrgSymbol:"",
        
        player:"",
        symbol:"",
        
        dept:"",
        move:""
    }
    
    
//    $scope.test=function()
//    {
//        $scope.box1Value='fa fa-circle-o fade';
//        $scope.box5Value='fa fa-times fade';
//        $scope.box9Value='fa fa-circle-o fade';
//    }
    
    
    function checkWin()
    {
        for(var i=0; i<3; i++)
        {   
            if(((tArray[i][0]==tArray[i][1]) && (tArray[i][0]==tArray[i][2])))
                return tArray[i][0];                 
            if(((tArray[0][i]==tArray[1][i]) && (tArray[0][i]==tArray[2][i])))
                return tArray[0][i];
        }
        if(((tArray[0][0]==tArray[1][1]) && (tArray[0][0]==tArray[2][2])))
            return tArray[0][0];
        if(((tArray[0][2]==tArray[1][1]) && (tArray[0][2]==tArray[2][0])))
            return tArray[0][2];  
        return false;
    }
    
    function gameOver(){
        var winReturn=checkWin();
        if(winReturn)
        {
            if(winReturn==gameState.OrgSymbol)
                return true;
            else
                return false;
        }
        return true;
        
    }
    function getAllPossMove(){
        for(var i=0; i<3; i++){
            if(tArray[i][0])
            {
                allPossMoves.push(i);
                allPossMoves.push(0);
            }            
            if(tArray[i][1])
            {
                allPossMoves.push(i);
                allPossMoves.push(1);
            }            
            if(tArray[i][2])
            {
                allPossMoves.push(i);
                allPossMoves.push(2);
            }
            
        }
    }
        
    function minimax(){
        if(gameOver())
        {
            
        }
    }
    
})

//Game Controller
.controller("multiController",function($scope)
{ 
    $scope.sp1Win=0;
    $scope.sp2Win=0;
    
    $scope.actCpu=function(){
        alert("Hello Disabled");
    }
});