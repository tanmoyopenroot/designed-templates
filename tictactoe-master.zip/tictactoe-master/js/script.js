function offNav(){
    $(".shitLeft").css({width:"0px"});
    $(".closeNav").css({visibility:"hidden"});
    $(".shitLeft>li").css({visibility:"hidden"});
    $(".shitLeft>li").css({transitionDelay:"0s"});
    
}

function onNav(){
    $(".shitLeft").css({width:"100%"});
    $(".closeNav").css({visibility:"visible"});
    $(".shitLeft>li").css({visibility:"visible"});
    $(".shitLeft>li").css({transitionDelay:"0.4s"}); 
}

function offScore(){
    $(".scoreContainer").css({width:"0%"}); 
    $(".scoreDtl").css({display:"none"});
    $(".win_text").removeClass("delay4_fade"); 
    $(".score_text").removeClass("delay5_slideInLeft"); 
    $(".score_value_text").removeClass("delay_slideInRight");
    $(".cpuScore").removeClass("delay8_slideInLeft");
    $(".input-btn").removeClass("delay8_fade pulse"); 
    
}
function onScore(){
    $(".scoreContainer").css({width:"100%"}); 
    $(".scoreDtl").css({display:"block"});
    $(".win_text").addClass("delay4_fade"); 
    $(".score_text").addClass("delay5_slideInLeft"); 
    $(".score_value_text").addClass("delay_slideInRight");
    $(".cpuScore").addClass("delay8_slideInLeft");
    $(".input-btn").addClass("delay8_fade pulse"); 
    
}