import { CollectionDef } from './collection-def';

export const Collections: CollectionDef[] =  [
  { id: 1, name: 'Ariadne’s Thread' },
  { id: 2, name: 'Black Swan' },
  { id: 3, name: 'Disco' },
  { id: 4, name: 'Discovering Greece' },
  { id: 5, name: 'Folding the News' },
  { id: 6, name: 'George C.' },
  { id: 7, name: 'Helen of Troy' },
  { id: 8, name: 'Hi-Tech' },
  { id: 9, name: 'Yokoso'},
  { id: 10, name: 'Mosquito'},
  { id: 11, name: 'Rainbow'},
  { id: 12, name: 'Ribbons'},
  { id: 13, name: 'Sophia'},
  { id: 14, name: 'The Fields'}
]
