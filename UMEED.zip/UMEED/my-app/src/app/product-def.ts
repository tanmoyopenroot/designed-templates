export class ProductDef{
  id: number;
  name: string;
  desc: string;
  img: string;
  price: number;
  qty: number;
}
