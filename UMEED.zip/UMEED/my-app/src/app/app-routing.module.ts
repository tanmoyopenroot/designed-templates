 import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'

import { AppComponent } from './app.component'
import { HomeComponent } from './home.component'
import { ShopComponent } from './shop.component'
import { AboutComponent } from './about.component'
import { BlogComponent } from './blog.component'
import { LogComponent } from './log.component'
import { BagComponent } from './bag.component'

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full'},
  { path: 'home', component: HomeComponent},
  { path: 'shop', component: ShopComponent },
  { path: 'about', component: AboutComponent },
  { path: 'blog', component: BlogComponent },
  { path: 'log',  component: LogComponent},
  { path: 'bag', component: BagComponent }
]

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})

export class AppRoutingModule {

}
