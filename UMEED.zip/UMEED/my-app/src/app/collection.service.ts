import { Injectable } from '@angular/core';

import { CollectionDef } from './collection-def';
import { Collections } from './collections'

@Injectable()
export class CollectionService {
  getCollections(): Promise<CollectionDef[]> {
    return Promise.resolve(Collections);
  }
}
