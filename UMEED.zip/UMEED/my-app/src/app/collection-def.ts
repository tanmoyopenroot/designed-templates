export class CollectionDef {
  id: number;
  name: string;
}
