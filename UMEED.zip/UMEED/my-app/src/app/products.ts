import { ProductDef } from "./product-def";

export const Products: ProductDef[] = [
  {
    id: 1,
    name: 'Rainbow Necklace Oval Sandwich',
    desc: 'Necklace Oval Sandwich series Rainbow, Handmade, Nine triple 25 mm discs made from colorful felt.',
    img: 'assets/img/showCase/3.jpg',
    price: 100,
    qty: 10
  },
  {
    id: 2,
    name: 'Rainbow Necklace Oval Sandwich',
    desc: 'Necklace Oval Sandwich series Rainbow, Handmade, Nine triple 25 mm discs made from colorful felt.',
    img: 'assets/img/showCase/4.jpg',
    price: 100,
    qty: 10
  },
 {
   id: 3,
   name: 'Rainbow Necklace Oval Sandwich',
   desc: 'Necklace Oval Sandwich series Rainbow, Handmade, Nine triple 25 mm discs made from colorful felt.',
   img: 'assets/img/showCase/3.jpg',
   price: 100,
   qty: 10
 },
 {
   id: 4,
   name: 'Rainbow Necklace Oval Sandwich',
   desc: 'Necklace Oval Sandwich series Rainbow, Handmade, Nine triple 25 mm discs made from colorful felt.',
   img: 'assets/img/showCase/4.jpg',
   price: 100,
   qty: 10
 },
 {
   id: 5,
   name: 'Rainbow Necklace Oval Sandwich',
   desc: 'Necklace Oval Sandwich series Rainbow, Handmade, Nine triple 25 mm discs made from colorful felt.',
   img: 'assets/img/showCase/3.jpg',
   price: 100,
   qty: 10
 },
 {
   id: 6,
   name: 'Rainbow Necklace Oval Sandwich',
   desc: 'Necklace Oval Sandwich series Rainbow, Handmade, Nine triple 25 mm discs made from colorful felt.',
   img: 'assets/img/showCase/4.jpg',
   price: 100,
   qty: 10
 }
]
