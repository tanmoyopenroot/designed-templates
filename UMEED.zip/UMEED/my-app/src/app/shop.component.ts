import { Component, OnInit} from '@angular/core';

import { ProductDef } from './product-def';
import { ProductService } from './product.service';

import { CollectionDef } from './collection-def';
import { CollectionService } from './collection.service';

@Component({
  selector: 'shop-section',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css'],
  providers: [CollectionService]
})

export class ShopComponent implements OnInit {
  products: ProductDef[];
  collections: CollectionDef[];

  constructor(private productService: ProductService, private collectionService: CollectionService) { }

  getProducts(): void {
    this.productService.getProducts().then(products => this.products = products);
  }

  getCollections(): void {
    this.collectionService.getCollections().then(collections => this.collections = collections);
  }

  getSelectedCollection(collection: CollectionDef): void {
    console.log("Getting Collection");
    console.log(collection.name);
    switch (collection.name) {
      case "value":
        // code...
        break;

      default:
        // code...
        break;
    }
  }

  ngOnInit(): void {
    this.getProducts();
    this.getCollections();
  }
}
