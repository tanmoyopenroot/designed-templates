import { Injectable } from '@angular/core';

import { ProductDef } from './product-def';
import { Products } from './products';

@Injectable()
export class ProductService {
  getProducts(): Promise<ProductDef[]> {
    return Promise.resolve(Products);
  }
}
