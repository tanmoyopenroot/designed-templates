import { Component } from '@angular/core'

@Component({
  selector: 'blog-section',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})

export class BlogComponent {

}
